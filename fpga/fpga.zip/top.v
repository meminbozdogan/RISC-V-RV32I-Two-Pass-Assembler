//=============================================================================
// Modül       : top
// Açıklama    : Üst Seviye SoC (System-on-Chip) Modülü
//               PicoRV32 işlemci + Dual-Port RAM + UART Loader entegrasyonu
//
//               Sistem Çalışma Modu:
//               1. YÜKLEME MODU: Reset sonrası CPU durdurulur, Loader FSM
//                  UART üzerinden gelen makine kodunu RAM'e yazar.
//               2. ÇALIŞTIRMA MODU: BOOT_CPU komutu alındığında CPU
//                  serbest bırakılır ve RAM'den program çalıştırır.
//
//               Bellek Haritası:
//                 0x0000_0000 - 0x0000_0FFF : RAM (4 KB, program + veri)
//                 0x0000_0400              : LED çıkışı (memory-mapped I/O)
//
//               Hedef Kart: Tang Nano 9K (Gowin GW1NR-9)
// Yazar       : Otomatik oluşturuldu
// Tarih       : 2026-06-03
//=============================================================================

module top (
    input  wire       clk,           // 27 MHz sistem saati
    input  wire       reset_btn,     // S1 butonu (aktif düşük, basılınca 0)
    output wire [5:0] leds,          // 6 adet LED çıkışı
    input  wire       uart_rx,       // UART RX girişi (PC → FPGA)
    output wire       uart_tx        // UART TX çıkışı (FPGA → PC)
);

    //=========================================================================
    // Parametre Tanımları
    //=========================================================================
    localparam CLK_FREQ      = 27_000_000;  // Tang Nano 9K: 27 MHz
    localparam BAUD_RATE     = 115200;       // UART baud hızı
    localparam RAM_ADDR_WIDTH = 10;          // 2^10 = 1024 kelime = 4 KB

    //=========================================================================
    // Reset Yönetimi
    // S1 butonu: basılı değilken HIGH (1), basılıyken LOW (0)
    // cpu_resetn: Loader tarafından kontrol edilir
    //   - Yükleme modunda: LOW (CPU durdu)
    //   - BOOT_CPU sonrası: HIGH (CPU çalışıyor)
    //=========================================================================
    wire sys_rst_n = reset_btn;       // Sistem reset (aktif düşük)
    wire cpu_running;                  // Loader'dan gelen CPU çalışma sinyali
    wire cpu_resetn = cpu_running;     // CPU reset = loader kontrolünde

    //=========================================================================
    // PicoRV32 CPU Sinyalleri
    //=========================================================================
    wire        mem_valid;
    wire [31:0] mem_addr;
    wire [31:0] mem_wdata;
    wire [3:0]  mem_wstrb;
    wire [31:0] mem_rdata;
    reg         mem_ready;

    //=========================================================================
    // UART Sinyalleri
    //=========================================================================
    wire [7:0] rx_data;
    wire       rx_valid;
    wire [7:0] tx_data;
    wire       tx_start;
    wire       tx_busy;

    //=========================================================================
    // RAM Sinyalleri
    //=========================================================================
    // Port A: CPU tarafı
    wire [RAM_ADDR_WIDTH-1:0] cpu_ram_addr;
    wire [31:0]               cpu_ram_rdata;

    // Port B: Loader tarafı
    wire [RAM_ADDR_WIDTH-1:0] loader_ram_addr;
    wire [31:0]               loader_ram_wdata;
    wire                      loader_ram_we;

    //=========================================================================
    // LED Register (Memory-Mapped I/O)
    // Adres: 0x0000_0400 (1024 ondalık)
    //=========================================================================
    reg [5:0] led_reg;

    //=========================================================================
    // Adres Çözümleme
    // RAM adresi: mem_addr[2 +: RAM_ADDR_WIDTH] → kelime adresi
    // (Alt 2 bit bayt ofseti, üst bitler kelime seçimi)
    //=========================================================================
    assign cpu_ram_addr = mem_addr[2 +: RAM_ADDR_WIDTH];

    // RAM alanı seçimi: adres 0x0000_0000 - 0x0000_0FFF arası
    wire ram_select = mem_valid && (mem_addr[31:12] == 20'h00000);

    // LED alanı seçimi: adres 0x0000_0400
    wire led_select = mem_valid && (mem_addr == 32'h0000_0400);

    //=========================================================================
    // CPU Okuma Verisi Multiplexer
    // RAM'den veya LED register'dan okuma
    //=========================================================================
    reg [31:0] mem_rdata_reg;

    always @(*) begin
        if (ram_select)
            mem_rdata_reg = cpu_ram_rdata;
        else
            mem_rdata_reg = 32'h0000_0000;
    end

    assign mem_rdata = mem_rdata_reg;

    //=========================================================================
    // Bellek Hazır Sinyali
    // Tek çevrimli bellek erişimi: mem_valid geldiğinde bir sonraki
    // çevrimde mem_ready verilir
    //=========================================================================
    always @(posedge clk) begin
        if (!sys_rst_n) begin
            mem_ready <= 1'b0;
        end else begin
            mem_ready <= mem_valid && !mem_ready;
        end
    end

    //=========================================================================
    // LED Register Yazma
    // CPU mem_addr==0x400 adresine yazdığında LED değerini güncelle
    //=========================================================================
    always @(posedge clk) begin
        if (!sys_rst_n) begin
            led_reg <= 6'b000000;
        end else if (led_select && (mem_wstrb != 4'b0000)) begin
            led_reg <= mem_wdata[5:0];
        end
    end

    // Tang Nano 9K: LED'ler aktif düşük (0=yanar, 1=söner)
    assign leds = ~led_reg;

    //=========================================================================
    // PicoRV32 İşlemci Çekirdeği
    //=========================================================================
    picorv32 #(
        .ENABLE_COUNTERS   (0),
        .ENABLE_REGS_16_31 (1),
        .PROGADDR_RESET    (32'h0000_0000),   // Program 0x0 adresinden başlar
        .STACKADDR         (32'h0000_0FFC)    // Stack en üst RAM adresi
    ) cpu (
        .clk       (clk),
        .resetn    (cpu_resetn),   // Loader kontrollü reset
        .mem_valid (mem_valid),
        .mem_addr  (mem_addr),
        .mem_wdata (mem_wdata),
        .mem_wstrb (mem_wstrb),
        .mem_rdata (mem_rdata),
        .mem_ready (mem_ready)
    );

    //=========================================================================
    // Çift Portlu RAM
    // Port A: CPU okuma/yazma
    // Port B: Loader yazma
    //=========================================================================
    dual_port_ram #(
        .ADDR_WIDTH (RAM_ADDR_WIDTH),
        .DATA_WIDTH (32)
    ) program_ram (
        .clk     (clk),

        // Port A - CPU
        .a_addr  (cpu_ram_addr),
        .a_wdata (mem_wdata),
        .a_wstrb ((ram_select) ? mem_wstrb : 4'b0000),
        .a_en    (ram_select),
        .a_rdata (cpu_ram_rdata),

        // Port B - Loader
        .b_addr  (loader_ram_addr),
        .b_wdata (loader_ram_wdata),
        .b_we    (loader_ram_we)
    );

    //=========================================================================
    // UART Alıcı (RX) - PC'den veri alma
    //=========================================================================
    uart_rx #(
        .CLK_FREQ  (CLK_FREQ),
        .BAUD_RATE (BAUD_RATE)
    ) uart_receiver (
        .clk      (clk),
        .rst_n    (sys_rst_n),
        .rx       (uart_rx),
        .rx_data  (rx_data),
        .rx_valid (rx_valid)
    );

    //=========================================================================
    // UART Verici (TX) - PC'ye yanıt gönderme
    //=========================================================================
    uart_tx #(
        .CLK_FREQ  (CLK_FREQ),
        .BAUD_RATE (BAUD_RATE)
    ) uart_transmitter (
        .clk      (clk),
        .rst_n    (sys_rst_n),
        .tx_data  (tx_data),
        .tx_start (tx_start),
        .tx       (uart_tx),
        .tx_busy  (tx_busy)
    );

    //=========================================================================
    // Loader Durum Makinesi
    // UART paketlerini çözümler, RAM'e yazar, CPU'yu kontrol eder
    //=========================================================================
    loader #(
        .RAM_ADDR_WIDTH (RAM_ADDR_WIDTH)
    ) program_loader (
        .clk         (clk),
        .rst_n       (sys_rst_n),

        // UART RX
        .rx_data     (rx_data),
        .rx_valid    (rx_valid),

        // UART TX
        .tx_data     (tx_data),
        .tx_start    (tx_start),
        .tx_busy     (tx_busy),

        // RAM yazma (Port B)
        .ram_addr    (loader_ram_addr),
        .ram_wdata   (loader_ram_wdata),
        .ram_we      (loader_ram_we),

        // CPU kontrol
        .cpu_running (cpu_running)
    );

endmodule