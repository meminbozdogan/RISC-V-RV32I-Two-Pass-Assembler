//=============================================================================
// Modül       : dual_port_ram
// Açıklama    : Çift Portlu RAM Modülü (True Dual-Port)
//               - Port A: CPU tarafı (okuma + yazma)
//               - Port B: Loader tarafı (yalnızca yazma)
//               - 1024 kelime x 32 bit = 4 KB kapasite
//               - Kelime adresli (word-addressed)
//               - Tang Nano 9K BRAM bloklarıyla sentezlenebilir
// Yazar       : Otomatik oluşturuldu
// Tarih       : 2026-06-03
//=============================================================================

module dual_port_ram #(
    parameter ADDR_WIDTH = 10,                    // Adres genişliği (10 bit = 1024 kelime)
    parameter DATA_WIDTH = 32                     // Veri genişliği (32 bit)
)(
    input  wire                    clk,           // Sistem saati

    // Port A - CPU Tarafı (Okuma + Yazma)
    input  wire [ADDR_WIDTH-1:0]   a_addr,        // CPU adres girişi (kelime adresi)
    input  wire [DATA_WIDTH-1:0]   a_wdata,       // CPU yazma verisi
    input  wire [3:0]              a_wstrb,       // CPU bayt yazma maskesi
    input  wire                    a_en,          // CPU port etkinleştirme
    output reg  [DATA_WIDTH-1:0]   a_rdata,       // CPU okuma verisi

    // Port B - Loader Tarafı (Yalnızca Yazma)
    input  wire [ADDR_WIDTH-1:0]   b_addr,        // Loader adres girişi (kelime adresi)
    input  wire [DATA_WIDTH-1:0]   b_wdata,       // Loader yazma verisi
    input  wire                    b_we           // Loader yazma etkinleştirme
);

    //=========================================================================
    // Bellek Dizisi
    // 2^ADDR_WIDTH kelime x DATA_WIDTH bit
    // Varsayılan: 1024 x 32 = 4 KB
    //=========================================================================
    reg [DATA_WIDTH-1:0] mem [0:(2**ADDR_WIDTH)-1];

    //=========================================================================
    // Bellek Başlangıç Değeri
    // Tüm belleği sıfırla (sentez aracı bunu BRAM init olarak kullanabilir)
    //=========================================================================
    integer i;
    initial begin
        for (i = 0; i < 2**ADDR_WIDTH; i = i + 1) begin
            mem[i] = {DATA_WIDTH{1'b0}};
        end
    end

    //=========================================================================
    // Port A - CPU Tarafı (Okuma + Yazma)
    // Senkron okuma ve bayt-maskelemeli yazma
    // PicoRV32'nin mem_wstrb sinyaliyle uyumlu (4 bayt maskesi)
    //=========================================================================
    always @(posedge clk) begin
        if (a_en) begin
            // Okuma (her zaman)
            a_rdata <= mem[a_addr];

            // Bayt-maskelemeli yazma
            if (a_wstrb[0]) mem[a_addr][ 7: 0] <= a_wdata[ 7: 0];
            if (a_wstrb[1]) mem[a_addr][15: 8] <= a_wdata[15: 8];
            if (a_wstrb[2]) mem[a_addr][23:16] <= a_wdata[23:16];
            if (a_wstrb[3]) mem[a_addr][31:24] <= a_wdata[31:24];
        end
    end

    //=========================================================================
    // Port B - Loader Tarafı (Yalnızca Yazma)
    // Loader FSM'den gelen tam kelime yazma
    // CPU ile eş zamanlı erişimi destekler
    //=========================================================================
    always @(posedge clk) begin
        if (b_we) begin
            mem[b_addr] <= b_wdata;
        end
    end

endmodule
